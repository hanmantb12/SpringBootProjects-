package com.orenda.xpert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrendabanklastApplicationTests {

	@Test
	void contextLoads() {
	}

}
